# Project_Covid
Written with HTML/CSS/Javascript
